CMS Public School — Single Index Edition

Single-file deployment modeled on a hash-routed static site:
  /           public home
  #/portal    portal login
  #/admin     admin workspace
  #/teacher   teacher workspace
  #/student   student workspace

No server-side /admin, /teacher, /student routing is required.
Deploy index.html as the repository root / Vercel root.

The Supabase URL and publishable key are embedded as client configuration; no service-role key or plaintext password is included.
